import { useState, useEffect, useRef } from "react";

export interface Track {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  durationSecs: number;
  price: string;
  albumPrice: string;
  img: string;
  genre: string;
  purchased?: boolean;
}

interface MusicPlayerProps {
  track: Track | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onClose: () => void;
  onBuy: (track: Track) => void;
  purchased: Set<number>;
}

const waveClasses = [
  "animate-wave-1",
  "animate-wave-2",
  "animate-wave-3",
  "animate-wave-4",
  "animate-wave-5",
  "animate-wave-6",
  "animate-wave-7",
  "animate-wave-8",
];

const barHeights = [35, 70, 55, 90, 65, 40, 80, 50, 75, 45, 85, 60, 38, 72, 52];

export default function MusicPlayer({ track, isPlaying, onTogglePlay, onClose, onBuy, purchased }: MusicPlayerProps) {
  const [progress, setProgress] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isPlaying && track) {
      timerRef.current = setInterval(() => {
        setElapsed((e) => {
          const next = e + 1;
          if (next >= 30) {
            clearInterval(timerRef.current!);
            onTogglePlay();
            return 30;
          }
          setProgress((next / 30) * 100);
          return next;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isPlaying, track]);

  useEffect(() => {
    setElapsed(0);
    setProgress(0);
  }, [track]);

  if (!track) return null;

  const isPurchased = purchased.has(track.id);
  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9997] border-t border-white/10"
      style={{ background: "rgba(15, 25, 35, 0.96)", backdropFilter: "blur(20px)" }}
    >
      {/* Progress bar */}
      <div className="h-0.5 bg-white/10 relative">
        <div
          className="absolute left-0 top-0 h-full bg-accent transition-all duration-1000"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-5 py-3 flex items-center gap-5">
        {/* Album art */}
        <div className="w-12 h-12 rounded-[8px] overflow-hidden bg-night-2 shrink-0">
          <img src={track.img} alt={track.title} className="w-full h-full object-cover" />
        </div>

        {/* Track info */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white truncate">{track.title}</p>
          <div className="flex items-center gap-2">
            <p className="text-xs text-white/50 truncate">{track.artist} · {track.album}</p>
            {!isPurchased && (
              <span className="text-xs text-accent/70 shrink-0">30s preview</span>
            )}
          </div>
        </div>

        {/* Waveform visualizer */}
        <div className="hidden sm:flex items-end gap-[2px] h-7 shrink-0">
          {barHeights.map((h, i) => (
            <div
              key={i}
              className={`w-[2px] rounded-full origin-bottom transition-colors ${
                isPlaying ? `${waveClasses[i % waveClasses.length]} bg-accent` : "bg-white/20"
              }`}
              style={{
                height: `${h}%`,
                animationDuration: isPlaying ? `${0.6 + (i % 5) * 0.08}s` : undefined,
              }}
            />
          ))}
        </div>

        {/* Time */}
        <div className="hidden md:flex items-center gap-1 shrink-0">
          <span className="text-xs text-white/40 font-mono">{fmt(elapsed)}</span>
          <span className="text-xs text-white/20">/</span>
          <span className="text-xs text-white/40 font-mono">{isPurchased ? track.duration : "0:30"}</span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <span className="text-white text-sm">{isPlaying ? "⏸" : "▶"}</span>
          </button>
        </div>

        {/* Buy / Owned */}
        {isPurchased ? (
          <div className="hidden sm:flex items-center gap-1.5 shrink-0">
            <span className="text-xs text-emerald-400 font-medium">✓ Owned</span>
          </div>
        ) : (
          <button
            onClick={() => onBuy(track)}
            className="hidden sm:block shrink-0 bg-accent hover:bg-accent-hover text-white text-xs font-semibold px-4 py-2 rounded-full transition-colors"
          >
            Buy {track.price}
          </button>
        )}

        {/* Close */}
        <button
          onClick={onClose}
          className="text-white/30 hover:text-white/70 transition-colors text-sm shrink-0"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
