import { useState } from "react";

type Page = "landing" | "feed" | "creator" | "product" | "discover" | "music";

interface NavProps {
  current: Page;
  onNavigate: (page: Page) => void;
}

export default function Nav({ current, onNavigate }: NavProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const isDark = current === "music";

  const linkClass = (page: Page) => {
    const active = current === page;
    return `text-sm font-medium transition-colors cursor-pointer ${
      isDark
        ? active ? "text-accent" : "text-white/50 hover:text-white/90"
        : active ? "text-primary" : "text-ink-muted hover:text-ink"
    }`;
  };

  const navBg = isDark
    ? "bg-night/90 border-white/10"
    : "bg-background/95 border-border";

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 h-16 backdrop-blur-sm border-b ${navBg} transition-colors duration-300`}>
      <div className="max-w-7xl mx-auto px-5 h-full flex items-center justify-between gap-6">
        {/* Logo mark */}
        <button
          onClick={() => onNavigate("landing")}
          className="flex items-center gap-2.5 shrink-0"
        >
          <span className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <span className="font-display italic text-white text-sm leading-none">c</span>
          </span>
        </button>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          <button className={linkClass("discover")} onClick={() => onNavigate("discover")}>Discover</button>
          <button className={linkClass("music")} onClick={() => onNavigate("music")}>
            <span className="flex items-center gap-1.5">
              Music
              <span className="text-[9px] font-bold bg-accent text-white px-1.5 py-0.5 rounded-full leading-none">NEW</span>
            </span>
          </button>
          <button className={linkClass("feed")} onClick={() => onNavigate("feed")}>Community</button>
          <button className={linkClass("creator")} onClick={() => onNavigate("creator")}>Creators</button>
        </div>

        {/* Desktop actions */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={() => onNavigate("feed")}
            className={`text-sm font-medium transition-colors ${isDark ? "text-white/40 hover:text-white/80" : "text-ink-muted hover:text-ink"}`}
          >
            Sign in
          </button>
          <button
            onClick={() => onNavigate("music")}
            className="text-sm font-medium bg-accent hover:bg-accent-hover text-white px-5 py-2 rounded-full transition-colors"
          >
            Join Free
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-1"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className={`block w-5 h-0.5 transition-all duration-200 ${isDark ? "bg-white/70" : "bg-ink"} ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-5 h-0.5 transition-all duration-200 ${isDark ? "bg-white/70" : "bg-ink"} ${menuOpen ? "opacity-0" : ""}`} />
          <span className={`block w-5 h-0.5 transition-all duration-200 ${isDark ? "bg-white/70" : "bg-ink"} ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className={`md:hidden absolute top-16 left-0 right-0 shadow-lg py-4 px-5 flex flex-col gap-4 border-b ${
          isDark ? "bg-night border-white/10" : "bg-background border-border"
        }`}>
          <button className={linkClass("discover")} onClick={() => { onNavigate("discover"); setMenuOpen(false); }}>Discover</button>
          <button className={linkClass("music")} onClick={() => { onNavigate("music"); setMenuOpen(false); }}>Music ✦</button>
          <button className={linkClass("feed")} onClick={() => { onNavigate("feed"); setMenuOpen(false); }}>Community</button>
          <button className={linkClass("creator")} onClick={() => { onNavigate("creator"); setMenuOpen(false); }}>Creators</button>
          <div className="flex gap-3 pt-2 border-t border-border">
            <button className={`text-sm font-medium ${isDark ? "text-white/40" : "text-ink-muted"}`} onClick={() => { onNavigate("feed"); setMenuOpen(false); }}>Sign in</button>
            <button className="text-sm font-medium bg-accent text-white px-5 py-2 rounded-full" onClick={() => { onNavigate("music"); setMenuOpen(false); }}>Join Free</button>
          </div>
        </div>
      )}
    </nav>
  );
}
