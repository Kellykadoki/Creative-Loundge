import { useState } from "react";
import Nav from "./components/Nav";
import MusicPlayer, { type Track } from "./components/MusicPlayer";
import Landing from "./pages/Landing";
import Feed from "./pages/Feed";
import CreatorProfile from "./pages/CreatorProfile";
import ProductDetail from "./pages/ProductDetail";
import Discover from "./pages/Discover";
import MusicStore from "./pages/MusicStore";

type Page = "landing" | "feed" | "creator" | "product" | "discover" | "music";

export default function App() {
  const [page, setPage] = useState<Page>("landing");
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [purchased, setPurchased] = useState<Set<number>>(new Set());

  const handleNavigate = (nextPage: Page) => {
    setPage(nextPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePlayTrack = (track: Track) => {
    if (currentTrack?.id === track.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentTrack(track);
      setIsPlaying(true);
    }
  };

  const handleBuy = (track: Track) => {
    setPurchased((prev) => new Set([...prev, track.id]));
    setIsPlaying(false);
  };

  const handleClosePlayer = () => {
    setCurrentTrack(null);
    setIsPlaying(false);
  };

  const handleTogglePlay = () => setIsPlaying((p) => !p);

  return (
    <div className="min-h-full font-sans" style={{ paddingBottom: currentTrack ? "68px" : "0" }}>
      <Nav current={page} onNavigate={handleNavigate} />

      {page === "landing" && (
        <Landing
          onNavigate={handleNavigate}
          onPlayTrack={handlePlayTrack}
          currentTrack={currentTrack}
          isPlaying={isPlaying}
        />
      )}
      {page === "feed" && <Feed onNavigate={handleNavigate} />}
      {page === "creator" && <CreatorProfile onNavigate={handleNavigate} />}
      {page === "product" && <ProductDetail onNavigate={handleNavigate} />}
      {page === "discover" && <Discover onNavigate={handleNavigate} />}
      {page === "music" && (
        <MusicStore
          onPlayTrack={handlePlayTrack}
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          purchased={purchased}
          onBuy={handleBuy}
        />
      )}

      <MusicPlayer
        track={currentTrack}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        onClose={handleClosePlayer}
        onBuy={handleBuy}
        purchased={purchased}
      />
    </div>
  );
}
