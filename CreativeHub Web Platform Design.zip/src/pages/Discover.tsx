import { useState } from "react";

type Page = "landing" | "feed" | "creator" | "product" | "discover";

interface DiscoverProps {
  onNavigate: (page: Page) => void;
}

type FilterType = "all" | "musicians" | "artists" | "producers" | "photographers" | "products";

const allItems = [
  { kind: "creator", name: "Maya Chen", discipline: "Visual Artist", location: "Los Angeles", followers: "4.2k", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&h=500&fit=crop&auto=format", tags: ["artists"] },
  { kind: "product", title: "Midnight Sessions Vol. 3", creator: "Marcus Webb", type: "Digital Album", price: "$12", img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&h=500&fit=crop&auto=format", tags: ["products", "musicians"] },
  { kind: "creator", name: "Marcus Webb", discipline: "Music Producer", location: "London", followers: "11.8k", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=500&fit=crop&auto=format", tags: ["producers"] },
  { kind: "product", title: "Azure Dreams", creator: "Maya Chen", type: "Art Print — 18×24", price: "$85", img: "https://images.unsplash.com/photo-1541367777708-7905fe3296c0?w=500&h=500&fit=crop&auto=format", tags: ["products", "artists"] },
  { kind: "creator", name: "Sofia Okafor", discipline: "Photographer", location: "Lagos", followers: "7.1k", img: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=500&h=500&fit=crop&auto=format", tags: ["photographers"] },
  { kind: "product", title: "Found in Translation", creator: "Sofia Okafor", type: "Photo Series", price: "$45", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500&h=500&fit=crop&auto=format", tags: ["products", "photographers"] },
  { kind: "creator", name: "Teo Nakamura", discipline: "Musician", location: "Tokyo", followers: "9.3k", img: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=500&h=500&fit=crop&auto=format", tags: ["musicians"] },
  { kind: "product", title: "Resonance EP", creator: "Teo Nakamura", type: "Digital Album + stems", price: "$18", img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=500&h=500&fit=crop&auto=format", tags: ["products", "musicians"] },
  { kind: "creator", name: "Leila Amara", discipline: "Textile Artist", location: "Beirut", followers: "2.9k", img: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=500&h=500&fit=crop&auto=format", tags: ["artists"] },
  { kind: "product", title: "Late Night Sessions", creator: "Marcus Webb", type: "Stems + Samples", price: "$28", img: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=500&h=500&fit=crop&auto=format", tags: ["products", "producers"] },
  { kind: "creator", name: "Dante Ferro", discipline: "Electronic Musician", location: "São Paulo", followers: "5.6k", img: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&h=500&fit=crop&auto=format", tags: ["musicians", "producers"] },
  { kind: "creator", name: "Priya Mehta", discipline: "Illustrator", location: "Mumbai", followers: "3.4k", img: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?w=500&h=500&fit=crop&auto=format", tags: ["artists"] },
];

const filters: { key: FilterType; label: string }[] = [
  { key: "all", label: "All" },
  { key: "musicians", label: "Musicians" },
  { key: "artists", label: "Visual Artists" },
  { key: "producers", label: "Producers" },
  { key: "photographers", label: "Photographers" },
  { key: "products", label: "Products" },
];

export default function Discover({ onNavigate }: DiscoverProps) {
  const [filter, setFilter] = useState<FilterType>("all");
  const [query, setQuery] = useState("");

  const filtered = allItems.filter((item) => {
    const matchesFilter = filter === "all" || item.tags.includes(filter);
    const searchText = item.kind === "creator" ? item.name ?? "" : item.title ?? "";
    const matchesQuery = query === "" || searchText.toLowerCase().includes(query.toLowerCase());
    return matchesFilter && matchesQuery;
  });

  return (
    <main className="pt-16 min-h-screen bg-background">
      {/* Header */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-5 py-10">
          <h1 className="font-display text-4xl text-ink mb-2">Discover</h1>
          <p className="text-ink-muted text-sm mb-7">Creators, works, and collaborators from around the world.</p>

          {/* Search bar */}
          <div className="relative max-w-lg">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted text-sm">⌕</span>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, discipline, or style..."
              className="w-full bg-background border border-border rounded-full pl-10 pr-5 py-3 text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:border-primary transition-colors"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-8">
        {/* Filter chips */}
        <div className="flex gap-2 flex-wrap mb-8">
          {filters.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`text-sm font-medium px-5 py-2 rounded-full border transition-colors ${
                filter === f.key
                  ? "bg-primary text-white border-primary"
                  : "bg-background text-ink-muted border-border hover:border-border-strong hover:text-ink"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Results count */}
        <p className="text-xs text-ink-muted mb-6">{filtered.length} result{filtered.length !== 1 ? "s" : ""}</p>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filtered.map((item, i) => {
            if (item.kind === "creator") {
              return (
                <button
                  key={`creator-${i}`}
                  onClick={() => onNavigate("creator")}
                  className="group text-left bg-background rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-lg transition-all duration-200"
                >
                  <div className="relative overflow-hidden bg-surface-2 aspect-square">
                    <img src={item.img} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute top-3 left-3">
                      <span className="text-xs font-medium bg-white/90 backdrop-blur-sm text-ink px-2.5 py-1 rounded-full">Creator</span>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-sm text-ink">{item.name}</h3>
                    <p className="text-xs text-ink-muted mt-0.5">{item.discipline}</p>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                      <span className="text-xs text-ink-muted">{item.location}</span>
                      <span className="text-xs text-ink-muted">{item.followers} followers</span>
                    </div>
                  </div>
                </button>
              );
            }

            return (
              <button
                key={`product-${i}`}
                onClick={() => onNavigate("product")}
                className="group text-left bg-surface rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-lg transition-all duration-200"
              >
                <div className="relative overflow-hidden bg-surface-2 aspect-square">
                  <img src={item.img} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute top-3 left-3">
                    <span className="text-xs font-medium bg-accent/90 backdrop-blur-sm text-white px-2.5 py-1 rounded-full">For sale</span>
                  </div>
                </div>
                <div className="p-4">
                  <p className="text-xs text-ink-muted mb-1">{item.type}</p>
                  <h3 className="font-medium text-sm text-ink leading-snug">{item.title}</h3>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <span className="font-semibold text-sm text-ink">{item.price}</span>
                    <span className="text-xs font-medium text-accent">Buy →</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <p className="font-display text-2xl text-ink mb-3">No results found</p>
            <p className="text-sm text-ink-muted">Try a different search or adjust your filters.</p>
            <button onClick={() => { setFilter("all"); setQuery(""); }} className="mt-6 text-sm text-primary underline underline-offset-4">Clear filters</button>
          </div>
        )}
      </div>
    </main>
  );
}
