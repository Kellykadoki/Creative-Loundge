import type { Track } from "../components/MusicPlayer";
import { allTracks } from "./MusicStore";

type Page = "landing" | "feed" | "creator" | "product" | "discover" | "music";

interface LandingProps {
  onNavigate: (page: Page) => void;
  onPlayTrack: (track: Track) => void;
  currentTrack: Track | null;
  isPlaying: boolean;
}

const creators = [
  { name: "Maya Chen", discipline: "Visual Artist", location: "Los Angeles", followers: "4.2k", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&auto=format", works: 18 },
  { name: "Marcus Webb", discipline: "Music Producer", location: "London", followers: "11.8k", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&auto=format", works: 34 },
  { name: "Sofia Okafor", discipline: "Photographer", location: "Lagos", followers: "7.1k", img: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=400&fit=crop&auto=format", works: 52 },
  { name: "Teo Nakamura", discipline: "Musician", location: "Tokyo", followers: "9.3k", img: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=400&h=400&fit=crop&auto=format", works: 22 },
];

const products = [
  { title: "Midnight Sessions Vol. 3", creator: "Marcus Webb", type: "Digital Album", price: "$12", img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=600&fit=crop&auto=format" },
  { title: "Azure Dreams", creator: "Maya Chen", type: "Art Print — 18×24", price: "$85", img: "https://images.unsplash.com/photo-1541367777708-7905fe3296c0?w=600&h=600&fit=crop&auto=format" },
  { title: "Found in Translation", creator: "Sofia Okafor", type: "Photo Series (12 prints)", price: "$45", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=600&fit=crop&auto=format" },
  { title: "Resonance EP", creator: "Teo Nakamura", type: "Digital Album + stems", price: "$18", img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=600&h=600&fit=crop&auto=format" },
];

const featuredMusicTracks = allTracks.slice(0, 4);

const barHeights = [35, 70, 55, 90, 65, 38, 80, 45, 72, 40];

export default function Landing({ onNavigate, onPlayTrack, currentTrack, isPlaying }: LandingProps) {
  return (
    <main>
      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden mesh-hero">
        {/* Animated orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(224,122,95,0.12) 0%, transparent 70%)", animation: "gradientDrift 10s ease-in-out infinite" }} />
        <div className="absolute bottom-1/4 right-1/3 w-80 h-80 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(45,84,145,0.2) 0%, transparent 70%)", animation: "gradientDrift 13s ease-in-out infinite reverse" }} />

        {/* Background image overlay */}
        <div className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1800&h=1200&fit=crop&auto=format')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            mixBlendMode: "luminosity",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-night/60" />

        <div className="relative max-w-7xl mx-auto px-5 pt-28 pb-24 w-full">
          <div className="max-w-3xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/8 backdrop-blur-sm border border-white/15 rounded-full px-4 py-1.5 mb-10">
              <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
              <span className="text-xs font-medium text-white/60 tracking-widest uppercase">For independent creators</span>
            </div>

            <h1 className="font-display text-6xl md:text-8xl text-white leading-[1.0] mb-8 tracking-tight">
              Your art,<br />
              <em className="not-italic" style={{ WebkitTextStroke: "1px rgba(224,122,95,0.8)", color: "transparent" }}>your terms</em>,<br />
              your people.
            </h1>

            <p className="text-white/50 text-xl leading-relaxed mb-10 max-w-lg">
              The platform where musicians, visual artists, and producers build real relationships with their audience — and earn directly.
            </p>

            <div className="flex flex-wrap gap-4 mb-16">
              <button
                onClick={() => onNavigate("feed")}
                className="bg-accent hover:bg-accent-hover text-white font-semibold text-sm px-8 py-4 rounded-full transition-all hover:shadow-[0_0_30px_rgba(224,122,95,0.4)]"
              >
                Join as a Creator
              </button>
              <button
                onClick={() => onNavigate("discover")}
                className="bg-white/8 hover:bg-white/15 backdrop-blur-sm border border-white/20 text-white/80 hover:text-white font-medium text-sm px-8 py-4 rounded-full transition-colors"
              >
                Explore the community →
              </button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-8 border-t border-white/10">
              {[["14k+", "Creators"], ["180k", "Fans & collectors"], ["$2.4M", "Paid to creators"]].map(([num, label]) => (
                <div key={label}>
                  <div className="font-display text-3xl text-white">{num}</div>
                  <div className="text-xs text-white/40 mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-float">
          <span className="text-xs text-white/30 tracking-widest uppercase">Scroll</span>
          <span className="text-white/30 text-xs">↓</span>
        </div>
      </section>

      {/* ── MUSIC ENGINE TEASER ── */}
      <section className="bg-night py-20 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 50% 80% at 90% 50%, rgba(224,122,95,0.08) 0%, transparent 60%)" }} />

        <div className="max-w-7xl mx-auto px-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10 mb-10">
            <div>
              <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-3">Music Engine</p>
              <h2 className="font-display text-4xl text-white">Hear it first.<br />Own it forever.</h2>
              <p className="text-white/40 text-sm mt-3 max-w-sm">Direct from artists to you. No label cut. Buy a track or full album and keep it forever.</p>
            </div>
            <button
              onClick={() => onNavigate("music")}
              className="shrink-0 bg-accent hover:bg-accent-hover text-white font-semibold text-sm px-7 py-3.5 rounded-full transition-all hover:shadow-[0_0_20px_rgba(224,122,95,0.4)]"
            >
              Open music store →
            </button>
          </div>

          {/* Featured tracks */}
          <div className="flex flex-col gap-px bg-white/5 rounded-[16px] overflow-hidden border border-white/10">
            {featuredMusicTracks.map((track, i) => {
              const isActive = currentTrack?.id === track.id;
              return (
                <div
                  key={track.id}
                  className={`group flex items-center gap-4 px-5 py-4 transition-colors cursor-pointer ${
                    isActive ? "bg-white/8" : "bg-night hover:bg-white/5"
                  } ${i > 0 ? "border-t border-white/5" : ""}`}
                  onClick={() => onPlayTrack(track)}
                >
                  {/* Index / waveform */}
                  <div className="w-8 flex items-center justify-center shrink-0">
                    {isActive && isPlaying ? (
                      <div className="flex items-end gap-[1.5px] h-4">
                        {barHeights.slice(0, 5).map((h, bi) => (
                          <div key={bi} className={`w-[2px] bg-accent rounded-full origin-bottom animate-wave-${bi + 1}`} style={{ height: `${h}%` }} />
                        ))}
                      </div>
                    ) : (
                      <>
                        <span className={`text-xs font-mono group-hover:hidden ${isActive ? "text-accent" : "text-white/25"}`}>
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <span className="text-white/50 text-sm hidden group-hover:block">▶</span>
                      </>
                    )}
                  </div>

                  {/* Art */}
                  <div className="w-10 h-10 rounded-[6px] overflow-hidden bg-night-2 shrink-0">
                    <img src={track.img} alt={track.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${isActive ? "text-accent" : "text-white/80"}`}>{track.title}</p>
                    <p className="text-xs text-white/35 truncate">{track.artist} · {track.album}</p>
                  </div>

                  {/* Duration */}
                  <span className="text-xs text-white/30 font-mono hidden sm:block">{track.duration}</span>

                  {/* Price */}
                  <span className="text-xs font-semibold text-accent/80">{track.price}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── VALUE PROPS ── */}
      <section className="py-24 mesh-section">
        <div className="max-w-7xl mx-auto px-5">
          <div className="text-center mb-16">
            <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-3">Why this platform</p>
            <h2 className="font-display text-4xl text-ink">Built for the work. Built for you.</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: "◎", title: "Direct connection", body: "No algorithm deciding who sees your work. Your fans subscribe to you, and every post lands in their feed." },
              { icon: "⬡", title: "True ownership", body: "Sell prints, albums, files, experiences. You set the price. You keep 90% of every sale — always." },
              { icon: "✦", title: "Collaborative spirit", body: "Find collaborators, post requests, build projects. The next great thing starts here." },
            ].map((prop) => (
              <div key={prop.title} className="group bg-background hover:bg-surface rounded-[16px] p-8 border border-border hover:border-border-strong transition-all duration-200">
                <div className="text-3xl text-accent mb-5 group-hover:animate-float inline-block">{prop.icon}</div>
                <h3 className="font-display text-xl text-ink mb-3">{prop.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{prop.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED CREATORS ── */}
      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-5">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-2">Featured creators</p>
              <h2 className="font-display text-4xl text-ink">People doing the work</h2>
            </div>
            <button onClick={() => onNavigate("discover")} className="hidden md:block text-sm font-medium text-primary hover:text-primary-hover underline underline-offset-4">
              See all creators
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {creators.map((creator) => (
              <button
                key={creator.name}
                onClick={() => onNavigate("creator")}
                className="group text-left bg-background rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-xl transition-all duration-200"
              >
                <div className="relative overflow-hidden bg-surface-2 h-52">
                  <img src={creator.img} alt={creator.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-ink text-sm">{creator.name}</h3>
                  <p className="text-ink-muted text-xs mt-0.5">{creator.discipline} · {creator.location}</p>
                  <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border">
                    <span className="text-xs text-ink-muted">{creator.followers} followers</span>
                    <span className="text-xs text-ink-muted">·</span>
                    <span className="text-xs text-ink-muted">{creator.works} works</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ── */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-5">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-2">New in the store</p>
              <h2 className="font-display text-4xl text-ink">Work worth owning</h2>
            </div>
            <button onClick={() => onNavigate("discover")} className="hidden md:block text-sm font-medium text-primary hover:text-primary-hover underline underline-offset-4">
              Browse all
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {products.map((product) => (
              <button
                key={product.title}
                onClick={() => onNavigate("product")}
                className="group text-left bg-surface rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-xl transition-all duration-200"
              >
                <div className="relative overflow-hidden bg-surface-2 aspect-square">
                  <img src={product.img} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-5">
                  <p className="text-xs text-ink-muted mb-1">{product.type}</p>
                  <h3 className="font-medium text-ink text-sm leading-snug mb-1">{product.title}</h3>
                  <p className="text-xs text-ink-faint">by {product.creator}</p>
                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                    <span className="font-semibold text-ink text-sm">{product.price}</span>
                    <span className="text-xs font-medium text-accent group-hover:underline">Buy →</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROCESS SECTION ── */}
      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-5 grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="rounded-[20px] overflow-hidden bg-surface-2 aspect-[4/3]">
              <img src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=900&h=675&fit=crop&auto=format" alt="Creator in studio" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-background border border-border rounded-[14px] p-5 shadow-xl max-w-[220px]">
              <p className="text-xs text-ink-muted mb-1">Latest update from</p>
              <p className="font-semibold text-sm text-ink">Marcus Webb</p>
              <p className="text-xs text-ink-muted mt-2 leading-relaxed">"Just wrapped the second session. The groove is there."</p>
              <p className="text-xs text-ink-faint mt-2">2 hours ago</p>
            </div>
          </div>

          <div>
            <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-4">Behind the work</p>
            <h2 className="font-display text-4xl text-ink leading-tight mb-6">The process is part of the art</h2>
            <p className="text-ink-muted leading-relaxed mb-6">Share progress, drafts, studio sessions, and the moments in between. When people witness the journey, they become invested — and they become your most loyal supporters.</p>
            <button onClick={() => onNavigate("feed")} className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary-hover transition-colors">
              See the community feed →
            </button>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="mesh-hero py-28 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 60% 80% at 50% 50%, rgba(224,122,95,0.1) 0%, transparent 70%)" }} />
        <div className="relative max-w-3xl mx-auto px-5 text-center">
          <h2 className="font-display text-5xl md:text-6xl text-white mb-6 leading-tight">
            Ready to share your<br />work with the world?
          </h2>
          <p className="text-white/50 text-lg mb-10">
            Join thousands of independent creators who found their audience — and their income.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => onNavigate("feed")}
              className="bg-accent hover:bg-accent-hover text-white font-semibold text-sm px-8 py-4 rounded-full transition-all hover:shadow-[0_0_30px_rgba(224,122,95,0.5)]"
            >
              Start for free
            </button>
            <button
              onClick={() => onNavigate("music")}
              className="bg-white/8 hover:bg-white/15 border border-white/20 text-white/80 hover:text-white font-medium text-sm px-8 py-4 rounded-full transition-colors"
            >
              Explore the music store
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-night border-t border-white/8 py-10">
        <div className="max-w-7xl mx-auto px-5 flex flex-col md:flex-row items-center justify-between gap-6">
          <span className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <span className="font-display italic text-white text-sm leading-none">c</span>
          </span>
          <div className="flex gap-8 text-sm text-white/30">
            {["About", "Pricing", "Blog", "Support", "Privacy"].map((l) => (
              <a key={l} href="#" className="hover:text-white/60 transition-colors">{l}</a>
            ))}
          </div>
          <p className="text-xs text-white/20">© 2026</p>
        </div>
      </footer>
    </main>
  );
}
