import { useState } from "react";
import type { Track } from "../components/MusicPlayer";

type Genre = "all" | "electronic" | "jazz" | "ambient" | "hip-hop" | "experimental";

interface MusicStoreProps {
  onPlayTrack: (track: Track) => void;
  currentTrack: Track | null;
  isPlaying: boolean;
  purchased: Set<number>;
  onBuy: (track: Track) => void;
}

export const allTracks: Track[] = [
  {
    id: 1,
    title: "Open Water",
    artist: "Marcus Webb",
    album: "Midnight Sessions Vol. 3",
    duration: "5:42",
    durationSecs: 342,
    price: "$1.50",
    albumPrice: "$12",
    img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&auto=format",
    genre: "electronic",
  },
  {
    id: 2,
    title: "Late Shift",
    artist: "Marcus Webb",
    album: "Midnight Sessions Vol. 3",
    duration: "4:18",
    durationSecs: 258,
    price: "$1.50",
    albumPrice: "$12",
    img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&auto=format",
    genre: "electronic",
  },
  {
    id: 3,
    title: "Resonance",
    artist: "Teo Nakamura",
    album: "Resonance EP",
    duration: "6:11",
    durationSecs: 371,
    price: "$1.00",
    albumPrice: "$8",
    img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=400&h=400&fit=crop&auto=format",
    genre: "ambient",
  },
  {
    id: 4,
    title: "City After Rain",
    artist: "Teo Nakamura",
    album: "Resonance EP",
    duration: "5:03",
    durationSecs: 303,
    price: "$1.00",
    albumPrice: "$8",
    img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=400&h=400&fit=crop&auto=format",
    genre: "ambient",
  },
  {
    id: 5,
    title: "Borrowed Time",
    artist: "Dante Ferro",
    album: "Phase Transitions",
    duration: "7:22",
    durationSecs: 442,
    price: "$1.50",
    albumPrice: "$14",
    img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop&auto=format",
    genre: "experimental",
  },
  {
    id: 6,
    title: "Red Light District",
    artist: "Dante Ferro",
    album: "Phase Transitions",
    duration: "5:48",
    durationSecs: 348,
    price: "$1.50",
    albumPrice: "$14",
    img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop&auto=format",
    genre: "experimental",
  },
  {
    id: 7,
    title: "Midnight Jazz",
    artist: "Marcus Webb",
    album: "Late Night Sessions",
    duration: "8:14",
    durationSecs: 494,
    price: "$2.00",
    albumPrice: "$18",
    img: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400&h=400&fit=crop&auto=format",
    genre: "jazz",
  },
  {
    id: 8,
    title: "Slow Burn",
    artist: "Teo Nakamura",
    album: "Resonance EP",
    duration: "4:55",
    durationSecs: 295,
    price: "$1.00",
    albumPrice: "$8",
    img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=400&h=400&fit=crop&auto=format",
    genre: "ambient",
  },
  {
    id: 9,
    title: "Glass City",
    artist: "Marcus Webb",
    album: "Midnight Sessions Vol. 3",
    duration: "6:03",
    durationSecs: 363,
    price: "$1.50",
    albumPrice: "$12",
    img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&auto=format",
    genre: "electronic",
  },
  {
    id: 10,
    title: "Pulse",
    artist: "Dante Ferro",
    album: "Phase Transitions",
    duration: "6:30",
    durationSecs: 390,
    price: "$1.50",
    albumPrice: "$14",
    img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop&auto=format",
    genre: "hip-hop",
  },
  {
    id: 11,
    title: "The Return",
    artist: "Marcus Webb",
    album: "Midnight Sessions Vol. 3",
    duration: "5:29",
    durationSecs: 329,
    price: "$1.50",
    albumPrice: "$12",
    img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&auto=format",
    genre: "electronic",
  },
  {
    id: 12,
    title: "Dusk Ritual",
    artist: "Teo Nakamura",
    album: "Resonance EP",
    duration: "5:17",
    durationSecs: 317,
    price: "$1.00",
    albumPrice: "$8",
    img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=400&h=400&fit=crop&auto=format",
    genre: "ambient",
  },
];

const albums = [
  { title: "Midnight Sessions Vol. 3", artist: "Marcus Webb", price: "$12", tracks: 6, img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=600&fit=crop&auto=format", genre: "Electronic · Jazz" },
  { title: "Resonance EP", artist: "Teo Nakamura", price: "$8", tracks: 5, img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=600&h=600&fit=crop&auto=format", genre: "Ambient · Electronic" },
  { title: "Phase Transitions", artist: "Dante Ferro", price: "$14", tracks: 8, img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&h=600&fit=crop&auto=format", genre: "Experimental · Electronic" },
  { title: "Late Night Sessions", artist: "Marcus Webb", price: "$18", tracks: 7, img: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&h=600&fit=crop&auto=format", genre: "Jazz · Lo-fi" },
];

const genres: { key: Genre; label: string }[] = [
  { key: "all", label: "All" },
  { key: "electronic", label: "Electronic" },
  { key: "ambient", label: "Ambient" },
  { key: "jazz", label: "Jazz" },
  { key: "hip-hop", label: "Hip-Hop" },
  { key: "experimental", label: "Experimental" },
];

const barHeights = [30, 65, 50, 85, 60, 38, 75, 45, 70, 40];

export default function MusicStore({ onPlayTrack, currentTrack, isPlaying, purchased, onBuy }: MusicStoreProps) {
  const [genre, setGenre] = useState<Genre>("all");
  const [view, setView] = useState<"tracks" | "albums">("tracks");
  const [query, setQuery] = useState("");

  const filteredTracks = allTracks.filter((t) => {
    const matchGenre = genre === "all" || t.genre === genre;
    const matchQuery = query === "" || t.title.toLowerCase().includes(query.toLowerCase()) || t.artist.toLowerCase().includes(query.toLowerCase());
    return matchGenre && matchQuery;
  });

  return (
    <main className="pt-16 min-h-screen bg-night" style={{ paddingBottom: currentTrack ? "80px" : "0" }}>
      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="mesh-hero py-20 px-5">
          {/* Floating orbs */}
          <div className="absolute top-10 right-20 w-64 h-64 rounded-full pointer-events-none"
            style={{ background: "radial-gradient(circle, rgba(224,122,95,0.15) 0%, transparent 70%)", animation: "gradientDrift 8s ease-in-out infinite" }} />
          <div className="absolute bottom-0 left-10 w-80 h-80 rounded-full pointer-events-none"
            style={{ background: "radial-gradient(circle, rgba(30,58,95,0.3) 0%, transparent 70%)", animation: "gradientDrift 11s ease-in-out infinite reverse" }} />

          <div className="relative max-w-7xl mx-auto">
            <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-5">Music Engine</p>
            <h1 className="font-display text-5xl md:text-7xl text-white leading-[1.05] mb-5">
              Hear it first.<br />
              <em className="not-italic text-accent">Own it forever.</em>
            </h1>
            <p className="text-white/50 text-lg max-w-xl mb-8">
              Direct from the artist to you. No label cut, no streaming tax. Buy a track, an album, or the stems — and support the people making the music.
            </p>

            {/* Search */}
            <div className="relative max-w-sm">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 text-sm">⌕</span>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tracks or artists..."
                className="w-full bg-white/10 border border-white/15 rounded-full pl-10 pr-5 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-accent/50 transition-colors"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-8">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          {/* Genre filters */}
          <div className="flex gap-2 flex-wrap">
            {genres.map((g) => (
              <button
                key={g.key}
                onClick={() => setGenre(g.key)}
                className={`text-xs font-medium px-4 py-1.5 rounded-full border transition-colors ${
                  genre === g.key
                    ? "bg-accent border-accent text-white"
                    : "border-white/15 text-white/50 hover:border-white/30 hover:text-white/80"
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>

          {/* View toggle */}
          <div className="flex items-center gap-1 bg-white/5 rounded-full p-1 self-start sm:self-auto">
            {(["tracks", "albums"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`text-xs font-medium px-4 py-1.5 rounded-full transition-colors capitalize ${
                  view === v ? "bg-white/10 text-white" : "text-white/40 hover:text-white/70"
                }`}
              >
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* TRACKS VIEW */}
        {view === "tracks" && (
          <div className="flex flex-col gap-1 mb-16">
            <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-x-4 items-center px-4 py-2 mb-2 border-b border-white/8">
              <span className="w-8" />
              <span className="text-xs text-white/30 uppercase tracking-widest font-medium">Track</span>
              <span className="text-xs text-white/30 uppercase tracking-widest font-medium hidden md:block">Album</span>
              <span className="text-xs text-white/30 uppercase tracking-widest font-medium hidden sm:block w-12 text-right">Time</span>
              <span className="text-xs text-white/30 uppercase tracking-widest font-medium w-20 text-right">Price</span>
            </div>

            {filteredTracks.map((track, i) => {
              const isActive = currentTrack?.id === track.id;
              const isPurchased = purchased.has(track.id);

              return (
                <div
                  key={track.id}
                  className={`group grid grid-cols-[auto_1fr_auto_auto_auto] gap-x-4 items-center px-4 py-3 rounded-[12px] transition-all cursor-pointer ${
                    isActive ? "bg-white/8 border border-white/10" : "hover:bg-white/5 border border-transparent"
                  }`}
                >
                  {/* Play button / track number */}
                  <div className="w-8 flex items-center justify-center">
                    {isActive && isPlaying ? (
                      <div className="flex items-end gap-[1.5px] h-4">
                        {barHeights.slice(0, 5).map((h, bi) => (
                          <div
                            key={bi}
                            className={`w-[2px] bg-accent rounded-full origin-bottom animate-wave-${bi + 1}`}
                            style={{ height: `${h}%` }}
                          />
                        ))}
                      </div>
                    ) : (
                      <button
                        onClick={() => onPlayTrack(track)}
                        className={`text-sm transition-colors ${isActive ? "text-accent" : "text-white/30 group-hover:text-white/80"}`}
                      >
                        {isActive && !isPlaying ? "▶" : isActive ? "▶" : i < 9 ? `0${i + 1}` : `${i + 1}`}
                      </button>
                    )}
                    {!isActive && (
                      <button
                        onClick={() => onPlayTrack(track)}
                        className="absolute text-white/0 group-hover:text-white/80 transition-colors text-sm"
                      >
                        ▶
                      </button>
                    )}
                  </div>

                  {/* Title + artist */}
                  <button
                    className="flex items-center gap-3 text-left min-w-0"
                    onClick={() => onPlayTrack(track)}
                  >
                    <div className="w-10 h-10 rounded-[6px] overflow-hidden bg-night-2 shrink-0">
                      <img src={track.img} alt={track.title} className="w-full h-full object-cover opacity-80" />
                    </div>
                    <div className="min-w-0">
                      <p className={`text-sm font-medium truncate ${isActive ? "text-accent" : "text-white/90"}`}>{track.title}</p>
                      <p className="text-xs text-white/40 truncate">{track.artist}</p>
                    </div>
                  </button>

                  {/* Album */}
                  <p className="text-xs text-white/35 hidden md:block truncate max-w-[160px]">{track.album}</p>

                  {/* Duration */}
                  <span className="text-xs text-white/35 font-mono hidden sm:block w-12 text-right">{track.duration}</span>

                  {/* Price + Buy */}
                  <div className="flex items-center gap-2 w-20 justify-end">
                    {isPurchased ? (
                      <span className="text-xs text-emerald-400 font-medium">✓ Owned</span>
                    ) : (
                      <button
                        onClick={() => onBuy(track)}
                        className="text-xs font-semibold text-white/50 hover:text-white border border-white/15 hover:border-accent hover:bg-accent/10 px-3 py-1.5 rounded-full transition-all"
                      >
                        {track.price}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredTracks.length === 0 && (
              <div className="text-center py-20">
                <p className="font-display text-2xl text-white/40 mb-2">No tracks found</p>
                <button onClick={() => { setGenre("all"); setQuery(""); }} className="text-sm text-accent/70 underline underline-offset-4">Clear filters</button>
              </div>
            )}
          </div>
        )}

        {/* ALBUMS VIEW */}
        {view === "albums" && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
            {albums.map((album) => {
              const firstTrack = allTracks.find((t) => t.album === album.title);
              return (
                <div
                  key={album.title}
                  className="group bg-white/5 border border-white/10 rounded-[16px] overflow-hidden hover:border-white/20 hover:bg-white/8 transition-all duration-200"
                >
                  <div className="relative aspect-square overflow-hidden bg-night-2">
                    <img src={album.img} alt={album.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300" />
                    <div className="absolute inset-0 bg-gradient-to-t from-night/60 to-transparent" />

                    {/* Play overlay */}
                    {firstTrack && (
                      <button
                        onClick={() => onPlayTrack(firstTrack)}
                        className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <span className="w-14 h-14 rounded-full bg-accent/90 flex items-center justify-center text-white text-xl shadow-lg">▶</span>
                      </button>
                    )}

                    <div className="absolute bottom-3 left-3">
                      <span className="text-xs text-white/60 font-medium">{album.tracks} tracks</span>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-sm text-white/90 leading-snug">{album.title}</h3>
                    <p className="text-xs text-white/45 mt-0.5">{album.artist}</p>
                    <p className="text-xs text-white/30 mt-1">{album.genre}</p>
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/10">
                      <span className="font-semibold text-sm text-white/80">{album.price}</span>
                      <button className="text-xs font-semibold bg-accent hover:bg-accent-hover text-white px-4 py-1.5 rounded-full transition-colors">
                        Buy album
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Sell your music CTA */}
        <div className="relative overflow-hidden rounded-[20px] p-8 mb-8"
          style={{
            background: "linear-gradient(135deg, rgba(30,58,95,0.6) 0%, rgba(224,122,95,0.3) 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <div className="absolute top-0 right-0 w-48 h-48 rounded-full pointer-events-none"
            style={{ background: "radial-gradient(circle, rgba(224,122,95,0.2) 0%, transparent 70%)", transform: "translate(30%, -30%)" }} />
          <div className="relative grid md:grid-cols-2 gap-6 items-center">
            <div>
              <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-3">For creators</p>
              <h2 className="font-display text-3xl text-white mb-3">Sell your music directly.</h2>
              <p className="text-white/50 text-sm leading-relaxed">
                Upload your tracks, set your own price, and keep 90% of every sale. No gatekeepers, no waiting for streaming royalties. Your fans buy directly from you.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 md:justify-end">
              <button className="bg-accent hover:bg-accent-hover text-white font-semibold text-sm px-6 py-3 rounded-full transition-colors">
                Start selling music
              </button>
              <button className="border border-white/20 text-white/70 hover:text-white font-medium text-sm px-6 py-3 rounded-full transition-colors">
                Learn how it works
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
