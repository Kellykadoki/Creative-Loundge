import { useState } from "react";

type Page = "landing" | "feed" | "creator" | "product" | "discover";

interface FeedProps {
  onNavigate: (page: Page) => void;
}

const posts = [
  {
    id: 1,
    author: "Maya Chen",
    discipline: "Visual Artist",
    location: "Los Angeles",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&auto=format",
    time: "2 hours ago",
    type: "process",
    typeLabel: "Process Update",
    content: "Started blocking out the new series today. Working with natural light only this month — no artificial sources at all. It's forcing me to work in shorter windows but the quality of light is doing something I couldn't replicate otherwise. These are rough, but the bones are there.",
    image: "https://images.unsplash.com/photo-1541367777708-7905fe3296c0?w=800&h=500&fit=crop&auto=format",
    likes: 142,
    comments: 18,
    liked: false,
  },
  {
    id: 2,
    author: "Marcus Webb",
    discipline: "Music Producer",
    location: "London",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&auto=format",
    time: "5 hours ago",
    type: "collab",
    typeLabel: "Collaboration Request",
    content: "Looking for a vocalist for my upcoming EP. Vibes: late night, introspective, jazz-influenced but modern. Think Hiatus Kaiyote meets Solange. You should be comfortable improvising and willing to experiment. DM me if that sounds like you — I have 4 tracks ready for vocals.",
    image: null,
    likes: 87,
    comments: 34,
    liked: false,
  },
  {
    id: 3,
    author: "Sofia Okafor",
    discipline: "Photographer",
    location: "Lagos",
    avatar: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop&auto=format",
    time: "1 day ago",
    type: "release",
    typeLabel: "New Release",
    content: "Found in Translation is now live in the store. Shot over 6 months across 4 countries — Lagos, Lisbon, Osaka, and Marrakech. Each image is about the moment just before or after something important. I hope you find your own meaning in them.",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=500&fit=crop&auto=format",
    likes: 310,
    comments: 52,
    liked: true,
  },
  {
    id: 4,
    author: "Teo Nakamura",
    discipline: "Musician",
    location: "Tokyo",
    avatar: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=100&h=100&fit=crop&auto=format",
    time: "2 days ago",
    type: "process",
    typeLabel: "Studio Session",
    content: "Day 11 of the album sessions. We finally cracked the bridge for track 3 — it's been haunting me for two months. Recording at 3am has something to it. The city goes quiet and you stop fighting the music and just follow it.",
    image: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&h=500&fit=crop&auto=format",
    likes: 224,
    comments: 41,
    liked: false,
  },
];

const newProducts = [
  { title: "Resonance EP", creator: "Teo Nakamura", price: "$18", img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=120&h=120&fit=crop&auto=format" },
  { title: "Azure Dreams", creator: "Maya Chen", price: "$85", img: "https://images.unsplash.com/photo-1541367777708-7905fe3296c0?w=120&h=120&fit=crop&auto=format" },
  { title: "Midnight Sessions Vol. 3", creator: "Marcus Webb", price: "$12", img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=120&h=120&fit=crop&auto=format" },
];

const suggestedCreators = [
  { name: "Leila Amara", discipline: "Textile Artist", location: "Beirut", img: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop&auto=format" },
  { name: "Dante Ferro", discipline: "Electronic Musician", location: "São Paulo", img: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop&auto=format" },
  { name: "Priya Mehta", discipline: "Illustrator", location: "Mumbai", img: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?w=80&h=80&fit=crop&auto=format" },
];

const typeColors: Record<string, string> = {
  process: "bg-primary/10 text-primary",
  collab: "bg-accent/10 text-accent",
  release: "bg-emerald-50 text-emerald-700",
};

export default function Feed({ onNavigate }: FeedProps) {
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set([3]));

  const toggleLike = (id: number) => {
    setLikedPosts((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <main className="pt-16 min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-5 py-10">
        {/* Page header */}
        <div className="mb-8">
          <h1 className="font-display text-3xl text-ink">Community feed</h1>
          <p className="text-ink-muted text-sm mt-1">Process updates, collaboration requests, and new releases from people you follow.</p>
        </div>

        <div className="grid lg:grid-cols-[1fr_300px] gap-8 items-start">
          {/* Main feed */}
          <div className="flex flex-col gap-5">
            {posts.map((post) => (
              <article
                key={post.id}
                className="bg-background border border-border rounded-[16px] overflow-hidden"
              >
                {/* Post header */}
                <div className="flex items-center justify-between p-5 pb-4">
                  <button
                    onClick={() => onNavigate("creator")}
                    className="flex items-center gap-3"
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-surface shrink-0">
                      <img src={post.avatar} alt={post.author} className="w-full h-full object-cover" />
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-sm text-ink">{post.author}</p>
                      <p className="text-xs text-ink-muted">{post.discipline} · {post.location}</p>
                    </div>
                  </button>
                  <div className="flex items-center gap-3">
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${typeColors[post.type]}`}>{post.typeLabel}</span>
                    <span className="text-xs text-ink-faint">{post.time}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="px-5 pb-4">
                  <p className="text-sm text-ink leading-relaxed">{post.content}</p>
                </div>

                {/* Image */}
                {post.image && (
                  <div className="overflow-hidden bg-surface mx-5 mb-4 rounded-[12px] aspect-[16/9]">
                    <img src={post.image} alt="Post image" className="w-full h-full object-cover" />
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center gap-6 px-5 py-4 border-t border-border">
                  <button
                    onClick={() => toggleLike(post.id)}
                    className="flex items-center gap-2 text-xs font-medium transition-colors"
                  >
                    <span className={`text-base leading-none transition-transform ${likedPosts.has(post.id) ? "scale-110" : ""}`}>
                      {likedPosts.has(post.id) ? "♥" : "♡"}
                    </span>
                    <span className={likedPosts.has(post.id) ? "text-accent" : "text-ink-muted"}>
                      {post.likes + (likedPosts.has(post.id) && post.id !== 3 ? 1 : likedPosts.has(post.id) ? 0 : post.id === 3 ? -1 : 0)} likes
                    </span>
                  </button>
                  <button className="flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors">
                    <span>○</span>
                    <span>{post.comments} comments</span>
                  </button>
                  <button className="text-xs font-medium text-ink-muted hover:text-ink transition-colors ml-auto">
                    Share
                  </button>
                </div>
              </article>
            ))}
          </div>

          {/* Sidebar */}
          <aside className="flex flex-col gap-6 lg:sticky lg:top-20">
            {/* New products */}
            <div className="bg-surface rounded-[16px] p-5 border border-border">
              <h3 className="font-semibold text-sm text-ink mb-4">New in the store</h3>
              <div className="flex flex-col gap-4">
                {newProducts.map((p) => (
                  <button
                    key={p.title}
                    onClick={() => onNavigate("product")}
                    className="flex items-center gap-3 text-left group"
                  >
                    <div className="w-12 h-12 rounded-[8px] overflow-hidden bg-surface-2 shrink-0">
                      <img src={p.img} alt={p.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-ink truncate group-hover:text-primary transition-colors">{p.title}</p>
                      <p className="text-xs text-ink-muted">{p.creator}</p>
                    </div>
                    <span className="text-xs font-semibold text-ink shrink-0">{p.price}</span>
                  </button>
                ))}
              </div>
              <button
                onClick={() => onNavigate("discover")}
                className="mt-4 pt-4 border-t border-border w-full text-xs font-medium text-primary hover:text-primary-hover text-left transition-colors"
              >
                Browse all products →
              </button>
            </div>

            {/* Suggested creators */}
            <div className="bg-surface rounded-[16px] p-5 border border-border">
              <h3 className="font-semibold text-sm text-ink mb-4">Suggested creators</h3>
              <div className="flex flex-col gap-4">
                {suggestedCreators.map((c) => (
                  <div key={c.name} className="flex items-center gap-3">
                    <button onClick={() => onNavigate("creator")} className="w-10 h-10 rounded-full overflow-hidden bg-surface-2 shrink-0">
                      <img src={c.img} alt={c.name} className="w-full h-full object-cover" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <button onClick={() => onNavigate("creator")} className="text-xs font-semibold text-ink hover:text-primary transition-colors">{c.name}</button>
                      <p className="text-xs text-ink-muted">{c.discipline} · {c.location}</p>
                    </div>
                    <button className="text-xs font-medium text-primary border border-primary/30 hover:bg-primary/5 px-3 py-1 rounded-full transition-colors">
                      Follow
                    </button>
                  </div>
                ))}
              </div>
              <button
                onClick={() => onNavigate("discover")}
                className="mt-4 pt-4 border-t border-border w-full text-xs font-medium text-primary hover:text-primary-hover text-left transition-colors"
              >
                Discover more creators →
              </button>
            </div>

            {/* Post a collab */}
            <div className="bg-primary rounded-[16px] p-5">
              <h3 className="font-semibold text-sm text-white mb-2">Looking to collaborate?</h3>
              <p className="text-xs text-white/60 leading-relaxed mb-4">Post a collab request and connect with artists whose work resonates with yours.</p>
              <button className="w-full bg-accent hover:bg-accent-hover text-white text-xs font-semibold py-2.5 rounded-full transition-colors">
                Post a request
              </button>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
