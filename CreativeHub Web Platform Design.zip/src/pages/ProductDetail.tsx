import { useState } from "react";

type Page = "landing" | "feed" | "creator" | "product" | "discover";

interface ProductDetailProps {
  onNavigate: (page: Page) => void;
}

const related = [
  { title: "Late Night Sessions", type: "Stems + Samples", price: "$28", img: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400&h=400&fit=crop&auto=format" },
  { title: "The Quiet Hours", type: "Instrumentals", price: "$15", img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop&auto=format" },
  { title: "Resonance EP", type: "Digital Album", price: "$8", img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=400&h=400&fit=crop&auto=format" },
];

const tracks = [
  { n: "01", title: "Open Water", dur: "5:42" },
  { n: "02", title: "Late Shift", dur: "4:18" },
  { n: "03", title: "Glass City", dur: "6:03" },
  { n: "04", title: "Midnight Sessions", dur: "7:11" },
  { n: "05", title: "The Return", dur: "5:29" },
  { n: "06", title: "Quiet Riot", dur: "3:58" },
];

export default function ProductDetail({ onNavigate }: ProductDetailProps) {
  const [purchased, setPurchased] = useState(false);
  const [wishlist, setWishlist] = useState(false);

  return (
    <main className="pt-16 min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-5 py-10">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-ink-muted mb-8">
          <button onClick={() => onNavigate("discover")} className="hover:text-ink transition-colors">Discover</button>
          <span>/</span>
          <button onClick={() => onNavigate("creator")} className="hover:text-ink transition-colors">Marcus Webb</button>
          <span>/</span>
          <span className="text-ink">Midnight Sessions Vol. 3</span>
        </nav>

        {/* Main layout */}
        <div className="grid lg:grid-cols-[1fr_380px] gap-12 mb-16">
          {/* Left: Product image + tracklist */}
          <div>
            <div className="rounded-[20px] overflow-hidden bg-surface aspect-square mb-6">
              <img
                src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=900&h=900&fit=crop&auto=format"
                alt="Midnight Sessions Vol. 3 album cover"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Track listing */}
            <div className="bg-surface rounded-[16px] border border-border overflow-hidden">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="font-semibold text-sm text-ink">Track listing</h3>
              </div>
              {tracks.map((track, i) => (
                <div
                  key={track.n}
                  className={`flex items-center gap-4 px-5 py-3.5 hover:bg-surface-2 transition-colors cursor-pointer ${
                    i < tracks.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <span className="text-xs text-ink-faint font-mono w-6 shrink-0">{track.n}</span>
                  <span className="text-sm text-ink flex-1">{track.title}</span>
                  <span className="text-xs text-ink-muted font-mono">{track.dur}</span>
                  <button className="text-ink-faint hover:text-accent transition-colors text-sm">▶</button>
                </div>
              ))}
              <div className="px-5 py-3 bg-surface-2 border-t border-border">
                <span className="text-xs text-ink-muted">Total: 32:41 · 6 tracks · Lossless FLAC + MP3</span>
              </div>
            </div>
          </div>

          {/* Right: Purchase panel */}
          <div className="lg:sticky lg:top-24 self-start">
            <div className="bg-background border border-border rounded-[20px] p-6">
              {/* Creator */}
              <button
                onClick={() => onNavigate("creator")}
                className="flex items-center gap-3 mb-6 group"
              >
                <div className="w-10 h-10 rounded-full overflow-hidden bg-surface">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&auto=format"
                    alt="Marcus Webb"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="text-left">
                  <p className="text-xs text-ink-muted">By</p>
                  <p className="text-sm font-semibold text-ink group-hover:text-primary transition-colors">Marcus Webb</p>
                </div>
                <span className="ml-auto text-xs text-ink-muted group-hover:text-ink transition-colors">Profile →</span>
              </button>

              {/* Title */}
              <h1 className="font-display text-2xl text-ink leading-snug mb-2">Midnight Sessions Vol. 3</h1>
              <p className="text-xs text-ink-muted mb-5">Digital Album · Released August 2026</p>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-6">
                <span className="font-display text-4xl text-ink">$12</span>
                <span className="text-xs text-ink-muted">or pay what you want</span>
              </div>

              {/* Buy button */}
              {!purchased ? (
                <button
                  onClick={() => setPurchased(true)}
                  className="w-full bg-accent hover:bg-accent-hover text-white font-semibold text-sm py-3.5 rounded-full transition-colors mb-3"
                >
                  Buy now — $12
                </button>
              ) : (
                <div className="w-full bg-emerald-50 border border-emerald-200 text-emerald-700 font-semibold text-sm py-3.5 rounded-full text-center mb-3">
                  ✓ Purchased — Download ready
                </div>
              )}

              <button
                onClick={() => setWishlist(!wishlist)}
                className={`w-full border text-sm font-medium py-3 rounded-full transition-colors mb-6 ${
                  wishlist
                    ? "border-primary text-primary bg-primary/5"
                    : "border-border text-ink-muted hover:border-border-strong hover:text-ink"
                }`}
              >
                {wishlist ? "♥ Saved to wishlist" : "♡ Save for later"}
              </button>

              <div className="flex flex-col gap-3 text-xs text-ink-muted">
                {[
                  "Instant download after purchase",
                  "Lossless FLAC + 320kbps MP3",
                  "Includes lyrics and liner notes PDF",
                  "90% of your purchase goes directly to Marcus",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-2">
                    <span className="text-accent mt-0.5">✓</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Creator note */}
            <div className="mt-4 bg-surface rounded-[16px] border border-border p-5">
              <p className="text-xs text-ink-muted italic leading-relaxed">
                "Vol. 3 came from a difficult year. I made most of it at 3am while everyone else was asleep. I hope it keeps you company the way making it kept me company."
              </p>
              <p className="text-xs font-semibold text-ink mt-3">— Marcus Webb</p>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="max-w-2xl mb-16">
          <h2 className="font-display text-2xl text-ink mb-4">About the album</h2>
          <p className="text-sm text-ink-muted leading-relaxed mb-4">
            Midnight Sessions Vol. 3 is the third installment in Marcus Webb's annual late-night series. Recorded entirely between November and January in his East London studio, the album captures the particular quality of winter midnight — still, expectant, and unsettled at the edges.
          </p>
          <p className="text-sm text-ink-muted leading-relaxed">
            Drawing on jazz harmony, UK club music, and ambient textures, the six tracks form a single arc from uncertainty to resolution. Vol. 3 is accompanied by a 24-page PDF with liner notes, session photographs, and complete lyrics.
          </p>
        </div>

        {/* Related */}
        <div>
          <h2 className="font-display text-2xl text-ink mb-6">More from Marcus Webb</h2>
          <div className="grid sm:grid-cols-3 gap-5">
            {related.map((p) => (
              <button
                key={p.title}
                className="group text-left bg-surface rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-md transition-all duration-200"
              >
                <div className="aspect-square overflow-hidden bg-surface-2">
                  <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-4">
                  <p className="text-xs text-ink-muted mb-1">{p.type}</p>
                  <h3 className="font-medium text-sm text-ink">{p.title}</h3>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <span className="font-semibold text-sm text-ink">{p.price}</span>
                    <span className="text-xs font-medium text-accent">Buy →</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
