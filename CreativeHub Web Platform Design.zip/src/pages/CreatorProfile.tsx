import { useState } from "react";

type Page = "landing" | "feed" | "creator" | "product" | "discover";

interface CreatorProfileProps {
  onNavigate: (page: Page) => void;
}

const products = [
  { title: "Midnight Sessions Vol. 3", type: "Digital Album", price: "$12", img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=600&fit=crop&auto=format", sales: 847 },
  { title: "Late Night Sessions", type: "Stems + Samples", price: "$28", img: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&h=600&fit=crop&auto=format", sales: 312 },
  { title: "Resonance EP", type: "Digital Album", price: "$8", img: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=600&h=600&fit=crop&auto=format", sales: 1204 },
  { title: "The Quiet Hours", type: "Instrumentals", price: "$15", img: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&h=600&fit=crop&auto=format", sales: 532 },
];

const updates = [
  {
    time: "2 hours ago",
    type: "Studio",
    content: "Just wrapped the second session on the new project. The groove is finally there. Recording late night has something to it — the city goes quiet and you stop fighting the music.",
    image: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&h=400&fit=crop&auto=format",
    likes: 224,
  },
  {
    time: "4 days ago",
    type: "Process",
    content: "Started mapping out the EP structure. Six tracks, all linked by the same two chord progressions but treated completely differently each time. Sound design week starts tomorrow.",
    image: null,
    likes: 158,
  },
  {
    time: "2 weeks ago",
    type: "Release",
    content: "Midnight Sessions Vol. 3 has now been heard by over 12,000 people. I'm genuinely floored. Thank you for listening.",
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&h=400&fit=crop&auto=format",
    likes: 891,
  },
];

type Tab = "store" | "updates" | "about" | "connections";

export default function CreatorProfile({ onNavigate }: CreatorProfileProps) {
  const [activeTab, setActiveTab] = useState<Tab>("store");
  const [following, setFollowing] = useState(false);

  const tabs: { key: Tab; label: string }[] = [
    { key: "store", label: "Store" },
    { key: "updates", label: "Updates" },
    { key: "about", label: "About" },
    { key: "connections", label: "Connections" },
  ];

  return (
    <main className="pt-16 min-h-screen bg-background">
      {/* Cover image */}
      <div
        className="relative h-56 md:h-72 bg-primary overflow-hidden"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1600&h=600&fit=crop&auto=format')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
      </div>

      {/* Profile header */}
      <div className="max-w-5xl mx-auto px-5">
        <div className="relative -mt-14 md:-mt-16 mb-6 flex flex-col md:flex-row md:items-end gap-5">
          {/* Avatar */}
          <div className="w-24 h-24 md:w-28 md:h-28 rounded-[16px] overflow-hidden border-4 border-background shadow-lg bg-surface shrink-0">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&auto=format"
              alt="Marcus Webb"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Name + bio */}
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl text-ink">Marcus Webb</h1>
                <p className="text-ink-muted text-sm mt-0.5">Music Producer · London, UK</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setFollowing(!following)}
                  className={`text-sm font-semibold px-6 py-2.5 rounded-full transition-colors ${
                    following
                      ? "bg-surface border border-border text-ink"
                      : "bg-primary hover:bg-primary-hover text-white"
                  }`}
                >
                  {following ? "Following" : "Follow"}
                </button>
                <button
                  onClick={() => onNavigate("product")}
                  className="text-sm font-semibold bg-accent hover:bg-accent-hover text-white px-6 py-2.5 rounded-full transition-colors"
                >
                  Buy work
                </button>
              </div>
            </div>

            {/* Stats row */}
            <div className="flex gap-6 mt-4">
              {[["11.8k", "Followers"], ["34", "Works"], ["$148k", "Earned"]].map(([n, l]) => (
                <div key={l}>
                  <span className="font-semibold text-sm text-ink">{n}</span>
                  <span className="text-xs text-ink-muted ml-1">{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Short bio */}
        <p className="text-ink-muted text-sm leading-relaxed max-w-2xl mb-6">
          Producer and composer based in London. I make music for late nights and long drives — jazz-influenced, electronic-edged, always searching for the space between genres. 12+ years in the studio, self-released everything since 2019.
        </p>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-border mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`text-sm font-medium px-4 py-2.5 border-b-2 transition-colors ${
                activeTab === tab.key
                  ? "border-accent text-accent"
                  : "border-transparent text-ink-muted hover:text-ink"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {activeTab === "store" && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 pb-16">
            {products.map((p) => (
              <button
                key={p.title}
                onClick={() => onNavigate("product")}
                className="group text-left bg-surface rounded-[16px] overflow-hidden border border-border hover:border-border-strong hover:shadow-md transition-all duration-200"
              >
                <div className="aspect-square overflow-hidden bg-surface-2">
                  <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-4">
                  <p className="text-xs text-ink-muted mb-1">{p.type}</p>
                  <h3 className="font-medium text-sm text-ink leading-snug">{p.title}</h3>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <span className="font-semibold text-sm text-ink">{p.price}</span>
                    <span className="text-xs text-ink-faint">{p.sales.toLocaleString()} sold</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {activeTab === "updates" && (
          <div className="max-w-2xl flex flex-col gap-6 pb-16">
            {updates.map((u, i) => (
              <article key={i} className="border border-border rounded-[16px] overflow-hidden">
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-medium bg-primary/10 text-primary px-2.5 py-1 rounded-full">{u.type}</span>
                    <span className="text-xs text-ink-faint">{u.time}</span>
                  </div>
                  <p className="text-sm text-ink leading-relaxed">{u.content}</p>
                </div>
                {u.image && (
                  <div className="bg-surface-2 aspect-[2/1] overflow-hidden mx-5 mb-5 rounded-[10px]">
                    <img src={u.image} alt="Update" className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="px-5 py-3 border-t border-border flex items-center gap-4">
                  <button className="text-xs text-ink-muted hover:text-accent transition-colors">♡ {u.likes}</button>
                  <button className="text-xs text-ink-muted hover:text-ink transition-colors">○ Comment</button>
                </div>
              </article>
            ))}
          </div>
        )}

        {activeTab === "about" && (
          <div className="max-w-2xl pb-16">
            <div className="bg-surface rounded-[16px] p-6 mb-5 border border-border">
              <h3 className="font-display text-xl text-ink mb-4">About Marcus</h3>
              <p className="text-sm text-ink-muted leading-relaxed mb-4">
                I grew up listening to everything — jazz, hip-hop, grime, classical. My father played bass in a jazz quartet in the 90s, and that sensibility lives in everything I make, even when the sounds are purely electronic.
              </p>
              <p className="text-sm text-ink-muted leading-relaxed">
                I left my label deal in 2019 to go independent, and I haven't looked back. I release everything myself, I set the terms, and I have a direct relationship with the people who listen. CreativeHub is a big part of how that works.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { label: "Based in", value: "London, UK" },
                { label: "Member since", value: "March 2021" },
                { label: "Genres", value: "Electronic, Jazz-influenced, Lo-fi" },
                { label: "Tools", value: "Ableton, Eurorack, SP-404" },
              ].map((row) => (
                <div key={row.label} className="bg-surface rounded-[12px] p-4 border border-border">
                  <p className="text-xs text-ink-muted mb-1">{row.label}</p>
                  <p className="text-sm font-medium text-ink">{row.value}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "connections" && (
          <div className="max-w-2xl pb-16">
            <p className="text-sm text-ink-muted mb-5">People Marcus has collaborated with or is connected to on CreativeHub.</p>
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { name: "Teo Nakamura", role: "Musician · Tokyo", img: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=80&h=80&fit=crop&auto=format", note: "Collaborated on Resonance EP" },
                { name: "Leila Amara", role: "Textile Artist · Beirut", img: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop&auto=format", note: "Visual direction, Late Night Sessions" },
                { name: "Maya Chen", role: "Visual Artist · Los Angeles", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&auto=format", note: "Cover art, Midnight Sessions Vol. 3" },
                { name: "Dante Ferro", role: "Electronic · São Paulo", img: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop&auto=format", note: "Mastering engineer" },
              ].map((c) => (
                <button
                  key={c.name}
                  onClick={() => onNavigate("creator")}
                  className="flex items-center gap-3 text-left bg-surface rounded-[12px] p-4 border border-border hover:border-border-strong transition-colors"
                >
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-surface-2 shrink-0">
                    <img src={c.img} alt={c.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-ink">{c.name}</p>
                    <p className="text-xs text-ink-muted">{c.role}</p>
                    <p className="text-xs text-ink-faint mt-0.5">{c.note}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
